<?php
/*
Plugin Name: MusicFlow Post Types
Plugin URI: #
Description: Add Custom Post Types for this theme
Version: 1.0
Author: paulrud
Author URI: http://themeforest.net/user/GOZAWI
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
*/

/*
Copyright 2015  Paul Rudnicki (email : themesfactoryinfor@gmail.com)

MusicFlow Post Types is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License, version 2, as
published by the Free Software Foundation.

MusicFlow Post Types is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with MusicFlow Post Types. If not, see license URI.
*/

if(!class_exists('MusicFlow_PostTypes'))
{
  class MusicFlow_PostTypes
  {
    /**
     * Construct the plugin object
     */
    public function __construct()
    {
      // Register custom post types
      require_once(sprintf("%s". DIRECTORY_SEPARATOR ."post-types" . DIRECTORY_SEPARATOR . "post_type_template.php", dirname(__FILE__)));
      $post_types = MusicFlowCustomPostType::Instance();

    } // END public function __construct

    /**
     * Activate the plugin
     */
    public static function activate()
    {
      // Do nothing
    } // END public static function activate

    /**
     * Deactivate the plugin
     */
    public static function deactivate()
    {
      // Do nothing
    } // END public static function deactivate


  } // END class MusicFlow_PostTypes
} // END if(!class_exists('MusicFlow_PostTypes'))

if(class_exists('MusicFlow_PostTypes'))
{
  // Installation and uninstallation hooks
  register_activation_hook(__FILE__, array('MusicFlow_PostTypes', 'activate'));
  register_deactivation_hook(__FILE__, array('MusicFlow_PostTypes', 'deactivate'));

  // instantiate the plugin class
  require_once(sprintf("%s". DIRECTORY_SEPARATOR ."post-types" . DIRECTORY_SEPARATOR . "post_type_template.php", dirname(__FILE__)));
  $post_types = MusicFlowCustomPostType::Instance();

}
