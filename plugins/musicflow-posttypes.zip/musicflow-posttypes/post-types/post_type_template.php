<?php
if(!class_exists('MusicFlowCustomPostType'))
{

    final class MusicFlowCustomPostType
    {

      public static function Instance()
      {
          static $inst = null;
          if ($inst === null) {
              $inst = new MusicFlowCustomPostType();
          }
          return $inst;
      }

      private function __construct(){

        add_action( 'init', array( $this, 'registerEvents' ) );
        add_action( 'init', array( $this, 'registerGalleries' ) );
        add_action( 'init', array( $this, 'registerVideos' ) );
        add_action( 'init', array( $this, 'registerAlbums' ) );

        add_action( 'init', array( $this, 'registerEventsPlaces' ));
        add_action( 'init', array( $this, 'registerGalleriesCategories' ));
        add_action( 'init', array( $this, 'registerVideosCategories' ));
        add_action( 'init', array( $this, 'registerAlbumsGenres' ));

        add_filter( 'manage_edit-musicflow-events_columns', array( $this, 'editEventsColumns' ) );
        add_filter( 'manage_edit-musicflow-galleries_columns', array( $this, 'editGalleriesColumns' ) );
        add_filter( 'manage_edit-musicflow-videos_columns', array( $this, 'editVideosColumns' ) );
        add_filter( 'manage_edit-musicflow-albums_columns', array( $this, 'editAlbumsColumns' ) );

        add_action( 'manage_musicflow-events_posts_custom_column' , array( $this, 'showEventsColumns'), 10, 2 );
        add_action( 'manage_musicflow-galleries_posts_custom_column', array( $this, 'showGalleriesColumns'),10, 2 );
        add_action( 'manage_musicflow-videos_posts_custom_column', array( $this, 'showVideosColumns'),10, 2 );
        add_action( 'manage_musicflow-albums_posts_custom_column', array( $this, 'showAlbumsColumns'),10, 2 );

      }

      public function registerEvents(){

        $args = array(
          'labels' => array(
              'name'               => __( 'Events', 'musicflow_theme' ),
              'singular_name'      => __( 'Event', 'musicflow_theme' ),
              'menu_name'          => __( 'Events', 'musicflow_theme' ),
              'name_admin_bar'     => __( 'Event', 'musicflow_theme' ),
              'add_new'            => __( 'Add New', 'musicflow_theme' ),
              'add_new_item'       => __( 'Add New Event', 'musicflow_theme' ),
              'new_item'           => __( 'New Event', 'musicflow_theme' ),
              'edit_item'          => __( 'Edit Event', 'musicflow_theme' ),
              'view_item'          => __( 'View Event', 'musicflow_theme' ),
              'all_items'          => __( 'All Events', 'musicflow_theme' ),
              'search_items'       => __( 'Search Events', 'musicflow_theme' ),
              'parent_item_colon'  => __( 'Parent Events:', 'musicflow_theme' ),
              'not_found'          => __( 'No events found.', 'musicflow_theme' ),
              'not_found_in_trash' => __( 'No events found in Trash.', 'musicflow_theme' )
          ),
          'public' => true,
          'publicty_queryable' => true,
          'show_ui' => true,
          'query_var' => true,
          'rewrite' => array( 'slug' => 'event' ),
          'capability_type' => 'post',
          'hierarchical' => true,
          'menu_position' => 5,
          'supports' => array(
              'title', 'editor', 'thumbnail', 'comments', 'author'
          ),
          'has_archive' => true,
          'menu_icon' => plugins_url( 'icons/admin_icon.png', __FILE__ ),
        );
        register_post_type('musicflow-events', $args);
      }

      public function registerEventsPlaces(){

        $labels = array(
          'name'              => __( 'Categories', 'musicflow_theme' ),
          'singular_name'     => __( 'Categorie', 'musicflow_theme' ),
          'search_items'      => __( 'Search Categories', 'musicflow_theme' ),
          'all_items'         => __( 'All Categories', 'musicflow_theme' ),
          'parent_item'       => __( 'Parent Categorie', 'musicflow_theme' ),
          'parent_item_colon' => __( 'Parent Categorie:', 'musicflow_theme' ),
          'edit_item'         => __( 'Edit Categorie', 'musicflow_theme' ),
          'update_item'       => __( 'Update Categorie', 'musicflow_theme' ),
          'add_new_item'      => __( 'Add New Categorie', 'musicflow_theme' ),
          'new_item_name'     => __( 'New Categorie Name', 'musicflow_theme' ),
          'menu_name'         => __( 'Categories', 'musicflow_theme' ),
        );

        $args = array(
          'hierarchical'          => true,
          'labels'                => $labels,
          'show_ui'               => true,
          'show_admin_column'     => true,
          'update_count_callback' => '_update_post_term_count',
          'query_var'             => true,
          'rewrite'               => array( 'slug' => 'events' )
        );

        register_taxonomy('musicflow-events-places', array( 'musicflow-events' ), $args);

        $labels = array(
          'name'                       => _x( 'Event Tags', 'musicflow_theme' ),
          'singular_name'              => _x( 'Tag', 'musicflow_theme' ),
          'search_items'               => __( 'Search Tags', 'musicflow_theme' ),
          'popular_items'              => __( 'Popular Tags', 'musicflow_theme' ),
          'all_items'                  => __( 'All Tags', 'musicflow_theme' ),
          'parent_item'                => null,
          'parent_item_colon'          => null,
          'edit_item'                  => __( 'Edit Tag', 'musicflow_theme' ),
          'update_item'                => __( 'Update Tag', 'musicflow_theme' ),
          'add_new_item'               => __( 'Add New Tag', 'musicflow_theme' ),
          'new_item_name'              => __( 'New Tag Name', 'musicflow_theme' ),
          'separate_items_with_commas' => __( 'Separate tags with commas', 'musicflow_theme' ),
          'add_or_remove_items'        => __( 'Add or remove tags', 'musicflow_theme' ),
          'choose_from_most_used'      => __( 'Choose from the most used tags', 'musicflow_theme' ),
          'not_found'                  => __( 'No tags found.', 'musicflow_theme' ),
          'menu_name'                  => __( 'Tags', 'musicflow_theme' ),
        );

        $args = array(
          'hierarchical'          => false,
          'labels'                => $labels,
          'show_ui'               => true,
          'show_admin_column'     => true,
          'update_count_callback' => '_update_post_term_count',
          'query_var'             => true,
          'rewrite'               => array( 'slug' => 'event-tag' ),
        );

        register_taxonomy('musicflow-events-tags', 'musicflow-events', $args);
      }

      public function editEventsColumns($columns){

        $columns = array(
            'cb' => "<input type=\"checkbox\" />",
            'title'     => __( 'Title', 'musicflow_theme' ),
            'place' =>  __( 'Place', 'musicflow_theme' ),
            'event_start' =>  __( 'Start', 'musicflow_theme' ),
            'event_end' =>  __( 'End', 'musicflow_theme' ),
            'location' =>  __( 'Location', 'musicflow_theme' ),
            'venue' =>  __( 'Venue', 'musicflow_theme' ),
            'price' =>  __( 'Price', 'musicflow_theme' ),
            'id' => __('ID', 'musicflow_theme' ),
        );

        return $columns;
      }

      public function showEventsColumns($column, $post_id){
        switch ( $column )
        {

          case 'place':
              $terms = get_the_term_list( $post_id , 'musicflow-events-places' , '' , ', ' , '' );
                    if ( is_string( $terms ) )
                echo $terms;
            else
                _e( 'No found places', 'musicflow_theme' );
            break;

              if($start = get_post_meta( $post_id, 'musicflow-prefix-' . 'event-date-time-start', true )):
                  echo date( _x( 'F d, Y', 'Event date format', 'musicflow_theme' ),  $start );
              else:
                  _e( "No start date.", 'musicflow_theme' );
              endif;
              break;
          case 'event_start':
              if($start = get_post_meta( $post_id, 'musicflow-prefix-' . 'event-date-time-start', true )):
                  echo date( _x( 'F d, Y', 'Event date format', 'musicflow_theme' ),  $start );
              else:
                  echo __( "No start date.", 'musicflow_theme' );
              endif;
              break;
          case 'event_end':
              if($end = get_post_meta( $post_id, 'musicflow-prefix-' . 'event-date-time-end', true )):
                echo date( _x( 'F d, Y', 'Event date format', 'musicflow_theme' ), $end);
              else:
                  echo __( "No end date.", 'musicflow_theme' );
              endif;
              break;
          case 'location':
              if( $location = get_post_meta( $post_id, 'musicflow-prefix-' . 'event-location', true )):
                  echo $location;
              else:
                  echo __( "No found location.", 'musicflow_theme' );
              endif;
              break;
          case 'venue':
              if($venue = get_post_meta( $post_id, 'musicflow-prefix-' . 'event-venue', true )):
                  echo $venue;
              else:
                  echo __( "No found vanue.", 'musicflow_theme' );
              endif;
              break;
          case 'price':
              if($price = get_post_meta( $post_id, 'musicflow-prefix-' . 'event-price', true )):
                  echo $price;
              else:
                  echo __( "No found price.", 'musicflow_theme' );
              endif;
              break;
          case 'id':
            echo $post_id;
            break;
        }
      }

        // GALLERY
        public function registerGalleries(){

        $args = array(
          'labels' => array(
              'name'               => __( 'Galleries', 'musicflow_theme' ),
              'singular_name'      => __( 'Gallery', 'musicflow_theme' ),
              'menu_name'          => __( 'Galleries', 'musicflow_theme' ),
              'name_admin_bar'     => __( 'Gallery', 'musicflow_theme' ),
              'add_new'            => __( 'Add New', 'musicflow_theme' ),
              'add_new_item'       => __( 'Add New Gallery', 'musicflow_theme' ),
              'new_item'           => __( 'New Gallery', 'musicflow_theme' ),
              'edit_item'          => __( 'Edit Gallery', 'musicflow_theme' ),
              'view_item'          => __( 'View Gallery', 'musicflow_theme' ),
              'all_items'          => __( 'All Galleries', 'musicflow_theme' ),
              'search_items'       => __( 'Search Galleries', 'musicflow_theme' ),
              'parent_item_colon'  => __( 'Parent Galleries:', 'musicflow_theme' ),
              'not_found'          => __( 'No Galleries found.', 'musicflow_theme' ),
              'not_found_in_trash' => __( 'No Galleries found in Trash.', 'musicflow_theme' )
          ),
          'public' => true,
          'publicty_queryable' => true,
          'show_ui' => true,
          'query_var' => true,
          'rewrite' => array( 'slug' => 'gallery' ),
          'capability_type' => 'post',
          'hierarchical' => true,
          'menu_position' => 5,
          'supports' => array(
              'title', 'editor', 'thumbnail', 'comments', 'author'
          ),
          'has_archive' => true,
          'menu_icon' => plugins_url( 'icons/admin_icon.png', __FILE__ ),
        );
        register_post_type('musicflow-galleries', $args);
      }

      public function registerGalleriesCategories(){

        $labels = array(
          'name'              => __( 'Gallery Categories', 'musicflow_theme' ),
          'singular_name'     => __( 'Category', 'musicflow_theme' ),
          'search_items'      => __( 'Search Categories', 'musicflow_theme' ),
          'all_items'         => __( 'All Categories', 'musicflow_theme' ),
          'parent_item'       => __( 'Parent Category', 'musicflow_theme' ),
          'parent_item_colon' => __( 'Parent Category:', 'musicflow_theme' ),
          'edit_item'         => __( 'Edit Category', 'musicflow_theme' ),
          'update_item'       => __( 'Update Category', 'musicflow_theme' ),
          'add_new_item'      => __( 'Add New Category', 'musicflow_theme' ),
          'new_item_name'     => __( 'New Category Name', 'musicflow_theme' ),
          'menu_name'         => __( 'Categories', 'musicflow_theme' ),
        );

        $args = array(
          'hierarchical'          => true,
          'labels'                => $labels,
          'show_ui'               => true,
          'show_admin_column'     => true,
          'update_count_callback' => '_update_post_term_count',
          'query_var'             => true,
          'rewrite'               => array( 'slug' => 'gallery-category' )
        );

        register_taxonomy('musicflow-galleries-category', array( 'musicflow-galleries' ), $args);


        $labels = array(
          'name'                       => _x( 'Gallery Tags', 'musicflow_theme' ),
          'singular_name'              => _x( 'Tag', 'musicflow_theme' ),
          'search_items'               => __( 'Search Tags', 'musicflow_theme' ),
          'popular_items'              => __( 'Popular Tags', 'musicflow_theme' ),
          'all_items'                  => __( 'All Tags', 'musicflow_theme' ),
          'parent_item'                => null,
          'parent_item_colon'          => null,
          'edit_item'                  => __( 'Edit Tag', 'musicflow_theme' ),
          'update_item'                => __( 'Update Tag', 'musicflow_theme' ),
          'add_new_item'               => __( 'Add New Tag', 'musicflow_theme' ),
          'new_item_name'              => __( 'New Tag Name', 'musicflow_theme' ),
          'separate_items_with_commas' => __( 'Separate tags with commas', 'musicflow_theme' ),
          'add_or_remove_items'        => __( 'Add or remove tags', 'musicflow_theme' ),
          'choose_from_most_used'      => __( 'Choose from the most used tags', 'musicflow_theme' ),
          'not_found'                  => __( 'No tags found.', 'musicflow_theme' ),
          'menu_name'                  => __( 'Tags', 'musicflow_theme' ),
        );

        $args = array(
          'hierarchical'          => false,
          'labels'                => $labels,
          'show_ui'               => true,
          'show_admin_column'     => true,
          'update_count_callback' => '_update_post_term_count',
          'query_var'             => true,
          'rewrite'               => array( 'slug' => 'gallery-tag' ),
        );

        register_taxonomy('musicflow-galleries-tags', 'musicflow-galleries', $args);
      }

      public function editGalleriesColumns($columns){

        $columns = array(
            'cb' => "<input type=\"checkbox\" />",
            'title'     => __( 'Title', 'musicflow_theme' ),
            'thumbnail' =>  __( 'Thumbnail', 'musicflow_theme' ),
            'cat' =>  __( 'Categories', 'musicflow_theme' ),
            'author' =>  __( 'Author', 'musicflow_theme' ),
            'date' =>  __( 'Date', 'musicflow_theme' ),
        );

        return $columns;
      }

      public function showGalleriesColumns($column, $post_id){
        switch ( $column )
        {
          case 'thumbnail':
            if(has_post_thumbnail($post_id)):
                echo get_the_post_thumbnail( $post_id, array(50,50) );
            else:
                echo __( "No thumbnail", 'musicflow_theme' );
            endif;
            break;
          case 'cat':
            $terms = get_the_term_list( $post_id, 'musicflow-galleries-category', '', ', ');
            echo $terms;
            break;
        }
      }

      // VIDEOS

      public function registerVideos(){

        $args = array(
          'labels' => array(
              'name'               => __( 'Videos', 'musicflow_theme' ),
              'singular_name'      => __( 'Video', 'musicflow_theme' ),
              'menu_name'          => __( 'Videos', 'musicflow_theme' ),
              'name_admin_bar'     => __( 'Video', 'musicflow_theme' ),
              'add_new'            => __( 'Add New', 'musicflow_theme' ),
              'add_new_item'       => __( 'Add New Video', 'musicflow_theme' ),
              'new_item'           => __( 'New Video', 'musicflow_theme' ),
              'edit_item'          => __( 'Edit Video', 'musicflow_theme' ),
              'view_item'          => __( 'View Video', 'musicflow_theme' ),
              'all_items'          => __( 'All Videos', 'musicflow_theme' ),
              'search_items'       => __( 'Search Videos', 'musicflow_theme' ),
              'parent_item_colon'  => __( 'Parent Videos:', 'musicflow_theme' ),
              'not_found'          => __( 'No Videos found.', 'musicflow_theme' ),
              'not_found_in_trash' => __( 'No Videos found in Trash.', 'musicflow_theme' )
          ),
          'public' => true,
          'publicty_queryable' => true,
          'show_ui' => true,
          'query_var' => true,
          'rewrite' => array( 'slug' => 'video' ),
          'capability_type' => 'post',
          'hierarchical' => true,
          'menu_position' => 5,
          'supports' => array(
              'title', 'editor', 'thumbnail', 'comments', 'author'
          ),
          'has_archive' => true,
          'menu_icon' => plugins_url( 'icons/admin_icon.png', __FILE__ ),
        );
        register_post_type('musicflow-videos', $args);
      }

      public function registerVideosCategories(){

        $labels = array(
          'name'              => __( 'Video Categories', 'musicflow_theme' ),
          'singular_name'     => __( 'Category', 'musicflow_theme' ),
          'search_items'      => __( 'Search Categories', 'musicflow_theme' ),
          'all_items'         => __( 'All Categories', 'musicflow_theme' ),
          'parent_item'       => __( 'Parent Category', 'musicflow_theme' ),
          'parent_item_colon' => __( 'Parent Category:', 'musicflow_theme' ),
          'edit_item'         => __( 'Edit Category', 'musicflow_theme' ),
          'update_item'       => __( 'Update Category', 'musicflow_theme' ),
          'add_new_item'      => __( 'Add New Category', 'musicflow_theme' ),
          'new_item_name'     => __( 'New Category Name', 'musicflow_theme' ),
          'menu_name'         => __( 'Categories', 'musicflow_theme' ),
        );

        $args = array(
          'hierarchical'          => true,
          'labels'                => $labels,
          'show_ui'               => true,
          'show_admin_column'     => true,
          'update_count_callback' => '_update_post_term_count',
          'query_var'             => true,
          'rewrite'               => array( 'slug' => 'video-category' )
        );

        register_taxonomy('musicflow-videos-category', array( 'musicflow-videos' ), $args);


        $labels = array(
          'name'                       => _x( 'Video Tags', 'musicflow_theme' ),
          'singular_name'              => _x( 'Tag', 'musicflow_theme' ),
          'search_items'               => __( 'Search Tags', 'musicflow_theme' ),
          'popular_items'              => __( 'Popular Tags', 'musicflow_theme' ),
          'all_items'                  => __( 'All Tags', 'musicflow_theme' ),
          'parent_item'                => null,
          'parent_item_colon'          => null,
          'edit_item'                  => __( 'Edit Tag', 'musicflow_theme' ),
          'update_item'                => __( 'Update Tag', 'musicflow_theme' ),
          'add_new_item'               => __( 'Add New Tag', 'musicflow_theme' ),
          'new_item_name'              => __( 'New Tag Name', 'musicflow_theme' ),
          'separate_items_with_commas' => __( 'Separate tags with commas', 'musicflow_theme' ),
          'add_or_remove_items'        => __( 'Add or remove tags', 'musicflow_theme' ),
          'choose_from_most_used'      => __( 'Choose from the most used tags', 'musicflow_theme' ),
          'not_found'                  => __( 'No tags found.', 'musicflow_theme' ),
          'menu_name'                  => __( 'Tags', 'musicflow_theme' ),
        );

        $args = array(
          'hierarchical'          => false,
          'labels'                => $labels,
          'show_ui'               => true,
          'show_admin_column'     => true,
          'update_count_callback' => '_update_post_term_count',
          'query_var'             => true,
          'rewrite'               => array( 'slug' => 'video-tag' ),
        );

        register_taxonomy('musicflow-videos-tags', 'musicflow-videos', $args);
      }

      public function editVideosColumns($columns){

        $columns = array(
          'cb' => "<input type=\"checkbox\" />",
          'title'     => __( 'Title', 'musicflow_theme' ),
          'thumbnail' =>  __( 'Thumbnail', 'musicflow_theme' ),
          'cat' =>  __( 'Categories', 'musicflow_theme' ),
          'author' =>  __( 'Author', 'musicflow_theme' ),
          'date' =>  __( 'Date', 'musicflow_theme' ),
        );

        return $columns;
      }

      public function showVideosColumns($column, $post_id){
        switch ( $column )
        {
          case 'thumbnail':
            if(has_post_thumbnail($post_id)):
                echo get_the_post_thumbnail( $post_id, array(50,50) );
            else:
                echo __( "No thumbnail", 'musicflow_theme' );
            endif;
            break;
          case 'cat':
            $terms = get_the_term_list( $post_id, 'musicflow-videos-category', '', ', ');
            echo $terms;
            break;
        }
      }

      // ALBUMS
      public function registerAlbums(){

        $args = array(
          'labels' => array(
              'name'               => __( 'Albums', 'musicflow_theme' ),
              'singular_name'      => __( 'Album', 'musicflow_theme' ),
              'menu_name'          => __( 'Albums', 'musicflow_theme' ),
              'name_admin_bar'     => __( 'Album', 'musicflow_theme' ),
              'add_new'            => __( 'Add New', 'musicflow_theme' ),
              'add_new_item'       => __( 'Add New Album', 'musicflow_theme' ),
              'new_item'           => __( 'New Album', 'musicflow_theme' ),
              'edit_item'          => __( 'Edit Album', 'musicflow_theme' ),
              'view_item'          => __( 'View Album', 'musicflow_theme' ),
              'all_items'          => __( 'All Albums', 'musicflow_theme' ),
              'search_items'       => __( 'Search Albums', 'musicflow_theme' ),
              'parent_item_colon'  => __( 'Parent Albums:', 'musicflow_theme' ),
              'not_found'          => __( 'No Albums found.', 'musicflow_theme' ),
              'not_found_in_trash' => __( 'No Albums found in Trash.', 'musicflow_theme' )
          ),
          'public' => true,
          'publicty_queryable' => true,
          'show_ui' => true,
          'query_var' => true,
          'rewrite' => array( 'slug' => 'album' ),
          'capability_type' => 'post',
          'hierarchical' => true,
          'menu_position' => 5,
          'supports' => array(
              'title', 'editor', 'thumbnail', 'comments', 'author'
          ),
          'has_archive' => true,
          'menu_icon' => plugins_url( 'icons/admin_icon.png', __FILE__ ),
        );
        register_post_type('musicflow-albums', $args);
      }

      public function registerAlbumsGenres(){

        $labels = array(
          'name'              => __( 'Album Genres', 'musicflow_theme' ),
          'singular_name'     => __( 'Genere', 'musicflow_theme' ),
          'search_items'      => __( 'Search Genres', 'musicflow_theme' ),
          'all_items'         => __( 'All Genres', 'musicflow_theme' ),
          'parent_item'       => __( 'Parent Genere', 'musicflow_theme' ),
          'parent_item_colon' => __( 'Parent Genere:', 'musicflow_theme' ),
          'edit_item'         => __( 'Edit Genere', 'musicflow_theme' ),
          'update_item'       => __( 'Update Genere', 'musicflow_theme' ),
          'add_new_item'      => __( 'Add New Genere', 'musicflow_theme' ),
          'new_item_name'     => __( 'New Genere Name', 'musicflow_theme' ),
          'menu_name'         => __( 'Genres', 'musicflow_theme' ),
        );

        $args = array(
          'hierarchical'          => true,
          'labels'                => $labels,
          'show_ui'               => true,
          'show_admin_column'     => true,
          'update_count_callback' => '_update_post_term_count',
          'query_var'             => true,
          'rewrite'               => array( 'slug' => 'genere' )
        );

        register_taxonomy('musicflow-albums-genres', array( 'musicflow-albums' ), $args);


        $labels = array(
          'name'                       => _x( 'Album Tags', 'musicflow_theme' ),
          'singular_name'              => _x( 'Tag', 'musicflow_theme' ),
          'search_items'               => __( 'Search Tags', 'musicflow_theme' ),
          'popular_items'              => __( 'Popular Tags', 'musicflow_theme' ),
          'all_items'                  => __( 'All Tags', 'musicflow_theme' ),
          'parent_item'                => null,
          'parent_item_colon'          => null,
          'edit_item'                  => __( 'Edit Tag', 'musicflow_theme' ),
          'update_item'                => __( 'Update Tag', 'musicflow_theme' ),
          'add_new_item'               => __( 'Add New Tag', 'musicflow_theme' ),
          'new_item_name'              => __( 'New Tag Name', 'musicflow_theme' ),
          'separate_items_with_commas' => __( 'Separate tags with commas', 'musicflow_theme' ),
          'add_or_remove_items'        => __( 'Add or remove tags', 'musicflow_theme' ),
          'choose_from_most_used'      => __( 'Choose from the most used tags', 'musicflow_theme' ),
          'not_found'                  => __( 'No tags found.', 'musicflow_theme' ),
          'menu_name'                  => __( 'Tags', 'musicflow_theme' ),
        );

        $args = array(
          'hierarchical'          => false,
          'labels'                => $labels,
          'show_ui'               => true,
          'show_admin_column'     => true,
          'update_count_callback' => '_update_post_term_count',
          'query_var'             => true,
          'rewrite'               => array( 'slug' => 'album-tag' ),
        );

        register_taxonomy('musicflow-albums-tags', 'musicflow-albums', $args);
      }

      public function editAlbumsColumns($columns){

        $columns = array(
            'cb' => "<input type=\"checkbox\" />",
            'title'     => __( 'Title', 'musicflow_theme' ),
            'thumbnail' =>  __( 'Thumbnail', 'musicflow_theme' ),
            'genres' =>  __( 'Genres', 'musicflow_theme' ),
            'relase_date' =>  __( 'Relase date', 'musicflow_theme' ),
            'artist' =>  __( 'Artist', 'musicflow_theme' ),
            'songs' =>  __( 'Songs', 'musicflow_theme' ),
            'id' =>  __( 'ID', 'musicflow_theme' ),
        );

        return $columns;
      }

      public function showAlbumsColumns($column, $post_id){
        switch ( $column )
        {
          case 'genres':
              $genres = get_the_term_list( $post_id, 'musicflow-albums-genres', '', ', ');
              if($genres):
                echo $genres;
              else:
                  echo __( "No genres.", 'musicflow_theme' );
              endif;
              break;
          case 'thumbnail':
            if($thumb = get_post_meta( $post_id, 'musicflow-prefix-' . 'album-image', true )):
                echo '<img src="'.$thumb.'" width="50" height="50" />';
            else:
                echo __( "No thumbnail", 'musicflow_theme' );
            endif;
            break;
          case 'relase_date':
              if($relase_date = get_post_meta( $post_id, 'musicflow-prefix-' . 'album-relase-date', true )):
                  echo date( _x( 'F d, Y', 'album date format', 'musicflow_theme' ), strtotime( $relase_date ) );
              else:
                  echo __( "No relase date.", 'musicflow_theme' );
              endif;
              break;
          case 'artist':
              if( $artists = get_post_meta( $post_id, 'musicflow-prefix-' . 'album-authors', true )):
                  foreach($artists as $artist):
                    echo $artist['name'] .'<br>';
                  endforeach;
              else:
                  echo __( "No artists.", 'musicflow_theme' );
              endif;
              break;
          case 'songs':
              if($songs = get_post_meta( $post_id, 'musicflow-prefix-' . 'album-songs', true )):
                  echo count($songs);
              else:
                  echo __( "No songs.", 'musicflow_theme' );
              endif;
              break;
          case 'id':
            echo $post_id;
            break;
        }
      }

    }

} // END if(!class_exists('MusicFlowCustomPostType'))
